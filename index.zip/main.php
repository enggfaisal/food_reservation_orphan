<!DOCTYPE html>
<html>
<body style="background: SkyBlue;padding: 15% 30% 15% 30%;">
	<title>main page</title>
	<div id="login-main" align="center">
	<a href="home.php" ><button  style="margin-top: 20px;height:30px;width:100px"">See_all </button></a><br>
	<a href="vol.php" ><button  style="margin-top: 20px;height:30px;width:100px"">See volunteer </button></a><br>
	<a href="recv.php" ><button  style="margin-top: 20px;height:30px;width:100px"">for receive</button></a><br>
	<a href="feedback.php" ><button  style="margin-top: 20px;height:30px;width:100px"">for feedback </button></a><br>

	</div>
	</body>
	</html>
