<?php
echo "invalid username and password.<br>Goto to login page and enter vaild username and password:";
?>
<html>
<body>
<a href="index.php" > <button style="margin-top: 20px;height:30px;width:100px"> go back</button></a>
</body>
</html>
