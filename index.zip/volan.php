
<!DOCTYPE html>
<html>
<head>
    <title>Smart Food Distribution</title>
    <link rel="stylesheet" type="text/css" href="style.css">

         <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
          <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
</head>
<body>
  <div class="bgimage" >
    <div class="menu">
        <div class="leftmenu">
            <h4>Smart Food Distribution</h4>
        </div>
        <div class="rightmenu">
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="addarea.php">Add Area</a></li>
                <li><a href="volan.php">Add Volunteer</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="login.php">login</a></li>
                <li><a href="request.php">Food Request</a></li>
                
            </ul>
        </div>
    </div> 
    <div id="login-main" align="center">
</div>
<head>
    <meta charset="utf-8">
    <title>Registation Page</title>
    <link rel="stylesheet" type="text/css" href="new.css">
</head>
<body >
  <div class="box" align="">
        <h2>Add Volunteer</h2>
<form action="Inss.php" method="POST" enctype="multipart/form-data">
    <label style="color: white">Name</label><br>
    <input type="text" name="nam"><br>

    <label style="color: white">address</label><br>
    <input type="text" name="add"><br>
    <label style="color: white">phone Number</label><br>
    <input type="text" name="phn"><br>

    <label style="color: white">email</label><br>
    <input type="text" name="eml"><br>
    <label style="color: white">Date</label><br>
    <input type="Date" name="date"><br>
    <input type="submit" name="btn" value="add"><br>




  </form>
    
  </div>
</body>
</html>