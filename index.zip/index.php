<!DOCTYPE html>
<html>
<head>
	<title>Smart Food Distribution</title>
	<link rel="stylesheet" type="text/css" href="style.css">

		 <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
		  <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
</head>
<body>
  <div class="bgimage" >
  	<div class="menu">
  		<div class="leftmenu">
  			<h4>Smart Food Distribution</h4>
  		</div>
  		<div class="rightmenu">
  			<ul>
  			    <li><a href="index.php">HOME</a></li>
  				<li><a href="addarea.php">Add Area</a></li>
  				<li><a href="volan.php">Add Volunteer</a></li>
  				<li><a href="about.php">About Us</a></li>
  				<li><a href="login.php">login</a></li>
                <li><a href="request.php">Food Request</a></li>
  				
  			</ul>
  		</div>
  	</div> 
  	<div class="text">
  		<h4>SMART.FOOD.DISTRIBUTION</h4>
  		<h1>SERVE & STAY HAPPY</h1>
  		<h3>WE ARE FIRST IN BD WHO PROVIDE THIS SERVICE</h3>
  		<button id="button1">LIKE-SHARE</button>
  		<button id="button2">SUBSCRIBE US</button>
  	</div>
  </div>
</body>
</html>