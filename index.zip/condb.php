<?php
$host="localhost";
$user="root";
$pwd="";
$dbname="reg";
$con=mysqli_connect($host,$user,$pwd,$dbname);

?>