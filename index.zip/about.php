<!DOCTYPE html>
<html>
<head>
	<title>Welcome to Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">

		 <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700%7CPT+Serif:400,700,400italic' rel='stylesheet'>
		  <link href="https://fonts.googleapis.com/css?family=Montserrat|Open+Sans" rel="stylesheet">
</head>
<body>
  </head>
<body>
  <div class="bgimage" >
    <div class="menu">
      <div class="leftmenu">
        <h4>Smart Food Distribution</h4>
      </div>
      <div class="rightmenu">
        <ul>
          <li><a href="index.php">HOME</a></li>
          <li><a href="addarea.php">Add Area</a></li>
          <li><a href="volan.php">Add Volunteer</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="login.php">login</a></li>
                <li><a href="request.php">Food Request</a></li>
          
        </ul>
      </div>
    </div> 
<head>
	<meta charset="utf-8">
	<title>Registation Page</title>
	<link rel="stylesheet" type="text/css" href="about.css">
</head>
<body>
  <div class="box">
		<h2>OUR INSTRUCTOR</h2>
<form action="" method="post" enctype="multipart/form-data">
  	<div class="inputbox">
    	 <input type="submit" name="" required="" Value="Md Masdul Islam">
    </div>
    <div class="inputbox">
    	 <input type="submit" name="" required="" Value="Lecturer of BUBT">
    </div>
  </form>

  <div class="box2">
		<h3>OUR TEAM</h3>
<form action="" method="post" enctype="multipart/form-data">
  	<div class="inputbox">
    	<input type="submit" name="" required="" Value="Nasir Uddin Khan">  
    </div>
    <div class="inputbox">
    	<input type="submit" name="" required="" Value="Md Faisal Ahmed">  
    </div>
    <div class="inputbox">
    	<input type="submit" name="" required="" Value="Jannatul Fredous">  
    </div>
    <div class="inputbox">
    	<input type="submit" name="" required="" Value="Swarnali Sarkar">  
    </div>
    <div class="inputbox">
      <input type="submit" name="" required="" Value="Hajeera Nasrin">  
    </div>
  </form>

  </div>


